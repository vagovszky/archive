QT
==

Qt projects

portcomsender - send data to arduinu through serial port (/dev/ACM0)