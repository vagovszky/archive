#include "widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    port = new QSerialPort(this);

    if(!init_port()) exit(1);

    slider = new QSlider(this);
    slider->resize(255,20);
    slider->setOrientation( Qt::Horizontal);
    slider->setRange(0,255);

    lcd = new QLCDNumber(this);
    lcd->setSegmentStyle(QLCDNumber::Flat);
    lcd->setFixedSize(180,100);

    main_layout = new QVBoxLayout(this);
    main_layout->addWidget(slider);
    main_layout->addWidget(lcd);

    this->setLayout(main_layout);

    connect(slider, SIGNAL(valueChanged(int)), this, SLOT(transmitCmd(int)));
    connect(slider, SIGNAL(valueChanged(int)), lcd, SLOT(display(int)));
}

Widget::~Widget()
{
    port->close();
}

bool Widget::init_port()
{
    QString portName = "/dev/ttyACM0";
    port->setPortName(portName);

    if (!port->open(QIODevice::WriteOnly)) {
        QString msg = tr("Can not open port")+" "+portName+", "+port->errorString();
        QMessageBox::critical(this, tr("Error"), msg);
        return false;
    }

    if (!port->setBaudRate(QSerialPort::Baud9600)) {
        QMessageBox::critical(this, tr("Failed to set 9600 baud"), port->errorString());
        return false;
    }

    if (!port->setDataBits(QSerialPort::Data8)) {
        QMessageBox::critical(this, tr("Failed to set 8 data bits"), port->errorString());
        return false;
    }

    if (!port->setParity(QSerialPort::NoParity)) {
        QMessageBox::critical(this, tr("Failed to set no parity"), port->errorString());
        return false;
    }

    if (!port->setStopBits(QSerialPort::OneStop)) {
        QMessageBox::critical(this, tr("Failed to set 1 stop bit"), port->errorString());
        return false;
    }

    if (!port->setFlowControl(QSerialPort::NoFlowControl)) {
        QMessageBox::critical(this, tr("Failed to set no flow control"), port->errorString());
        return false;
    }
    return true;
}

void Widget::transmitCmd(int value)
{
  if(value < 0 || value >255) return;
  char c;
  c = (char) value;
  port->putChar(c);

}
