var connection = new autobahn.Connection({url: 'ws://localhost:9090/', realm: 'realm1'});

connection.onopen = function (session) {
    // 1) subscribe to a topic
    /*
    function onevent(args) {
        console.log("Event:", args[0]);
    }
    session.subscribe('com.myapp.hello', onevent);
    */
    // 2) publish an event
    /*
    session.publish('com.myapp.hello', ['Message from javascript!']);
    */
    // 3) register a procedure for remoting
    /*
    function add2(args) {
        return args[0] + args[1];
    }
    session.register('com.myapp.add2', add2);
    */
    // 4) call a remote procedure
    session.call('add2', [10, 3]).then(
        function (res) {
            console.log("Result:", res);
        }
    );
            
};

connection.open();