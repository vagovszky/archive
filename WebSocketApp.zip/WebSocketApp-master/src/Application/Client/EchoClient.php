<?php

namespace Application\Client;

class EchoClient extends \Thruway\Peer\Client
{

    public function echoBack($str)
    {
        return [$str];
    }

    
    public function onSessionStart($session, $transport)
    {
        $session->register('echoback', [$this, 'echoBack']);
    }

}
