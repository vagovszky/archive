<?php

namespace Application\InternalClient;

use React\EventLoop\LoopInterface;

/**
 * Class InternalClient
 */
class MyClient extends \Thruway\Peer\Client
{

    /**
     * Contructor
     */
    public function __construct($realm, LoopInterface $loop = null)
    {
        parent::__construct($realm, $loop);
    }

    /**
     * @param \Thruway\ClientSession $session
     * @param \Thruway\Transport\TransportInterface $transport
     */
    public function onSessionStart($session, $transport)
    {
        $session->register('getphpversion', [$this, 'getPhpVersion']);
    }

    /**
     * Handle get PHP version
     *
     * @return array
     */
    public function getPhpVersion()
    {
        return [phpversion()];
    }

}