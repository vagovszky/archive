<?php
return array(
    'assets_bundle' => array(
        'production' => false,
    ),
);

