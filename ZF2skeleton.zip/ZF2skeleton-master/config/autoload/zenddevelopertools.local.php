<?php
return array(
    'zenddevelopertools' => array(
        'profiler' => array(
            'enabled' => true,
            'strict' => true,
            'flush_early' => false,
            'cache_dir' => 'data/cache',
            'matcher' => array(),
            'collectors' => array('db' => null)
        ),
        'events' => array(
            'enabled' => true,
            'collectors' => array(),
            'identifiers' => array()
        ),
        'toolbar' => array(
            'enabled' => true,
            'auto_hide' => false,
            'position' => 'bottom',
            'version_check' => false,
            'entries' => array()
        )
    )
);
