<?php
return array(
    'zfcadmin' => array(
        'use_admin_layout' => false,
        //'admin_layout_template' => 'layout/admin',
    ),
);
