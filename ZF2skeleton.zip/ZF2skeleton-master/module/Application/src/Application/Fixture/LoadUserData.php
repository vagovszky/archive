<?php

namespace Application\Fixture;

use Application\Entity\User;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\FixtureInterface;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;

class LoadUserData extends AbstractFixture implements FixtureInterface, DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $user = new User();
        $user->setUsername('administrator');
        $user->setEmail('admin@admin.com');
        $user->setPassword('$2y$14$nwBn67TJY/mWlmBRI.oNf.XjiZbJy3RybLMk8z0rwkqkiHAzK.qAe'); //administrator
        $user->setDisplayName("administrator");
        $user->setState(1);
        $user->addRole($this->getReference('admin-role'));

        $manager->persist($user);
        $manager->flush();
        
    }
    
    public function getDependencies()
    {
        return array('Application\Fixture\LoadUserRoles'); // fixture classes fixture is dependent on
    }
}