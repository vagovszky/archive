<?php

namespace Application\Fixture;

use Application\Entity\Role;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\FixtureInterface;

class LoadUserRoles extends AbstractFixture implements FixtureInterface
{
    public function load(ObjectManager $manager)
    {
        // guest
        $role_guest = new Role();
        $role_guest->setRoleId('guest');
        
        // user
        $role_user = new Role();
        $role_user->setRoleId('user');
        
        // admin
        $role_admin = new Role();
        $role_admin->setParent($role_user);
        $role_admin->setRoleId('admin');
        
        $manager->persist($role_guest);
        $manager->persist($role_user);
        $manager->persist($role_admin);
        $manager->flush();
        
        $this->addReference('admin-role', $role_admin);
    }
}