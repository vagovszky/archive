bet-database
===============

Chance Database module
