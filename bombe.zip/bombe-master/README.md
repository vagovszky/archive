Demo application
=================

This is my demo application. 
Available from:

- http://www.bombe.cz

Installation
------------
- clone this project
- create database from data/database.sql
- php composer.phar install
- configure files in config/autoload (rename *.php.dist to *.php)
- check .htacces in public folder
- make dirs /public/cache, /data writeable

Administration credentials
--------------------------

email: admin@y2k.cz 
passworld: tojemojeheslo