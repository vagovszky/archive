<?php
return array(
    'bjyauthorize' => array(

        'default_role' => 'guest',
        'identity_provider' => 'BjyAuthorize\Provider\Identity\AuthenticationIdentityProvider',
        'role_providers'        => array(
            'BjyAuthorize\Provider\Role\ObjectRepositoryProvider' => array(
                'object_manager'    => 'doctrine.entitymanager.orm_default',
                'role_entity_class' => 'Application\Entity\Role',
            ),
        ),
        'guards' => array(
            'BjyAuthorize\Guard\Route' => array(
                array('route' => 'home', 'roles' => array('guest', 'user')),
                
                array('route' => 'zfcuser', 'roles' => array('user')),
                array('route' => 'zfcuser/logout', 'roles' => array('user')),
                array('route' => 'zfcuser/login', 'roles' => array('guest','user')),
                array('route' => 'zfcuser/register', 'roles' => array('guest', 'user')),
                array('route' => 'zfcuser/authenticate', 'roles' => array('guest')),
                array('route' => 'zfcuser/changepassword', 'roles' => array('user')),
                array('route' => 'zfcuser/changeemail', 'roles' => array('user')),
                
                array('route' => 'zfcadmin', 'roles' => array('user')),
                array('route' => 'zfcadmin/datastorage', 'roles' => array('user')),
                array('route' => 'zfcadmin/datastorage/upload', 'roles' => array('admin')),
                array('route' => 'zfcadmin/datastorage/success', 'roles' => array('admin')),
                
                array('route' => 'doctrine_orm_module_yuml', 'roles' => array('guest','user')),
                
                array('route' => 'contact', 'roles' => array('guest','user')),
                array('route' => 'contact/process', 'roles' => array('guest','user')),
                array('route' => 'contact/thank-you', 'roles' => array('guest','user'))
            ),
        ),
    ),
);