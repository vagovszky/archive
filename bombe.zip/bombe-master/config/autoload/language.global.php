<?php
return array(
    'translator' => array(
        'locale' => 'cs_CZ',
    )
);
?>
