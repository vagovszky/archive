<?php
/*
 * http://samsonasik.wordpress.com/2012/11/18/zend-framework-2-dynamic-navigation-using-zend-navigation/#more-1857
 * http://zf2.readthedocs.org/en/latest/modules/zend.view.helpers.navigation.html
 */
return array(
    'navigation' => array(
        'default' => array(
            'home' => array(
                'label' => 'Home',
                'route' => 'home',
                'resource' => 'route/home',
            ),
            'contact' => array(
                'label' => 'Contact',
                'route' => 'contact',
                'resource' => 'route/contact',
            ),
        ),
        'admin' => array(
            'home' => array(
                'label' => 'Home',
                'route' => 'home',
                'resource' => 'route/home'
            ),
            'datastorage' => array(
                'label' => 'Data storage',
                'route' => 'zfcadmin/datastorage',
                'resource' => 'route/zfcadmin/datastorage',
                'pages' => array(
                     array(
                        'label' => 'Upload',
                        'route' => 'zfcadmin/datastorage/upload',
                        'resource' => 'route/zfcadmin/datastorage/upload',
                     ),
                    array(
                        'label' => 'Success',
                        'route' => 'zfcadmin/datastorage/success',
                        'resource' => 'route/zfcadmin/datastorage/success',
                     )
                 )
            ),
        ),
    ),
);