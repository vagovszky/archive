<?php

namespace Application;

use Zend\Mvc\ModuleRouteListener,
    Zend\Mvc\MvcEvent,
    Zend\ModuleManager\ModuleManager;
use Zend\Log\Logger;
use Zend\Log\Writer\Stream;
use Zend\Validator\AbstractValidator;

class Module {

    public function onBootstrap(MvcEvent $e) {
        $e->getApplication()->getServiceManager()->get('translator');
        $eventManager = $e->getApplication()->getEventManager();
        $sharedEventManager = $eventManager->getSharedManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
        $application = $e->getApplication();
        $serviceManager = $application->getServiceManager();
        $controllerLoader = $serviceManager->get('ControllerLoader');
        $entityManager = $serviceManager->get('doctrine.entitymanager.orm_default');
        // Add initializer to Controller Service Manager that check if controllers needs entity manager injection
        $controllerLoader->addInitializer(function ($instance) use ($entityManager) {
                    if (method_exists($instance, 'setEntityManager')) {
                        $instance->setEntityManager($entityManager);
                    }
                });
        // Log errors
        $eventManager->attach('dispatch.error', function($event) {
                    $exception = $event->getResult()->exception;
                    if ($exception) {
                        $sm = $event->getApplication()->getServiceManager();
                        $service = $sm->get('Application\Service\ErrorHandler');
                        $service->setException($exception);
                        $service->logException();
                    }
                });
        $translator = $serviceManager->get('mvc_translator');
        AbstractValidator::setDefaultTranslator($translator);

        // New user is registered as role user
        $sharedEventManager->attach('ZfcUser\Service\User', 'register', function($e) use ($entityManager) {
                    $user = $e->getParam('user');  // User account object
                    $role = $entityManager->getRepository('Application\Entity\Role')->findOneBy(array('roleId' => 'user'));
                    $user->addRole($role);
                });
    }

    public function init(ModuleManager $moduleManager) {
        
    }

    public function getConfig() {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig() {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getViewHelperConfig() {
        return array(
            'factories' => array(
                'navigation' => function($helperPluginManager) {
                    $auth = $helperPluginManager->getServiceLocator()->get('BjyAuthorize\Service\Authorize');
                    $role = $auth->getIdentityProvider()->getIdentityRoles();
                    if (is_array($role))
                        $role = $role[0];
                    $navigation = $helperPluginManager->get('Zend\View\Helper\Navigation');
                    $navigation->setAcl($auth->getAcl())->setRole($role);
                    $navigation->setTranslatorTextDomain(__NAMESPACE__);
                    return $navigation;
                },
            )
        );
    }
    /*
    public function getViewHelperConfig() {
        return array(
            'initializers' => array(
                function ($instance, $sm) {
                    if ($instance instanceof AbstractTranslatorHelper) {
                        $instance->setTranslatorTextDomain(__NAMESPACE__);
                    }
                }
            ),
        );
    }
    */
    public function getServiceConfig() {
        return array(
            'factories' => array(
                'Application\Service\ErrorHandler' => function($sm) {
                    $logger = $sm->get('Zend\Log');
                    $service = new Service\ErrorHandler($logger);
                    return $service;
                },
                'Zend\Log' => function ($sm) {
                    $filename = 'app_error_log_' . date('d-m-Y') . '.log';
                    $log = new Logger();
                    $writer = new Stream(ROOT_DIR . '/data/logs/' . $filename);
                    $log->addWriter($writer);
                    return $log;
                },
            ),
        );
    }

}
