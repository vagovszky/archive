<?php
/*
 * Translations for other parts of system such as Form etc. in default namespace
 */
return array(
    "Missing captcha fields" => "Chyba vyplnění polí captcha",
    "Authentication failed. Please try again." => "Autentikace selhala, zkuste to prosím znovu.",
    "Captcha value is wrong" => "Captcha není vyplněna správně",
);