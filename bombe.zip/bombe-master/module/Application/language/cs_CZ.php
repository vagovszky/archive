<?php
/*
 * Translations for other parts of system such as Form etc.
 */
return array(
    'Email' => 'Email:',
    'Password' => 'Heslo:',
    'Password Verify' => 'Heslo ověření:',
    'Please type the following text' => 'Opište text:',
    'Current Password' => 'Současné heslo:',
    'New Password' => 'Nové heslo:',
    'Verify New Password' => 'Potvrzení nového hesla:',
    'Submit' => 'Odeslat',
    'Data storage' => 'Dat. úložiště'
);