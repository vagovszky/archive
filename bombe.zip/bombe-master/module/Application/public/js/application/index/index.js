/**
 * Index controller index action javascript
 */
function AppIndexViewModel() {
    
}

// Activates knockout.js
ko.applyBindings(new AppIndexViewModel());

