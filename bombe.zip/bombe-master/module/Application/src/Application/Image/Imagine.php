<?php

namespace Application\Image;

use Imagine\Image\Color,
    Imagine\Image\ImagineInterface,
    Imagine\Image\BoxInterface,
    Imagine\Imagick,
    Imagine\Gd,
    Imagine\Gmagick;

/**
 * Třída pro práci s obrázky využívající třídu Imagine
 * @category Common
 * @package Image
 */
class Imagine implements ImagineInterface {

    /**
     * \Imagine\Image\ImagineInterface
     */
    private $imagine = null;

    public function __construct() {

        try { $this->imagine = new Gd\Imagine();      } catch (\Exception $e) {}
        try { $this->imagine = new Gmagick\Imagine(); } catch (\Exception $e) {}
        try { $this->imagine = new Imagick\Imagine(); } catch (\Exception $e) {}

        if (!$this->imagine) {
            throw new NoImageLibraryFound('No Image library found.');
        }
    }

    /**
     * Creates a new empty image with an optional background color
     *
     * @param \Imagine\Image\BoxInterface $size
     * @param \Imagine\Image\Color        $color
     *
     * @throws InvalidArgumentException
     * @throws RuntimeException
     *
     * @return \Imagine\Image\ImageInterface
     */
    public function create(BoxInterface $size, Color $color = null) {
        return $this->imagine->create($size, $color);
    }

    /**
     * Opens an existing image from $path
     *
     * @param string $path
     *
     * @throws RuntimeException
     *
     * @return \Imagine\Image\ImageInterface
     */
    public function open($path) {
        return $this->imagine->open($path);
    }

    /**
     * Loads an image from a binary $string
     *
     * @param string $string
     *
     * @throws RuntimeException
     *
     * @return \Imagine\Image\ImageInterface
     * @return \Imagine\Image\ImageInterface
     */
    public function load($string) {
        $this->imagine->load($string);
    }

    /**
     * Loads an image from a resource $resource
     *
     * @param resource $resource
     *
     * @throws RuntimeException
     *
     * @return \Imagine\Image\ImageInterface
     */
    public function read($resource) {
        return $this->imagine->read($resource);
    }

    /**
     * Constructs a font with specified $file, $size and $color
     *
     * The font size is to be specified in points (e.g. 10pt means 10)
     *
     * @param string  $file
     * @param integer $size
     * @param \Imagine\Image\Color   $color
     *
     * @return \Imagine\Image\FontInterface
     */
    public function font($file, $size, Color $color) {
        return $this->imagine->font($file, $size, $color);
    }

}

class NoImageLibraryFound extends \Exception {

}