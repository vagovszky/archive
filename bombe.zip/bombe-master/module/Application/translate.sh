#!/bin/bash
# TRANSLATE .phtml module files
# ------------------------------
LG="cs_CZ"
L_DIR="`dirname $0`/language/$LG.po"
touch "$L_DIR"
xgettext --from-code=UTF-8 --force-po -j -o "$L_DIR" --keyword=translate --language=PHP ` find . -type f -name *.phtml -name '*.phtml' -o -name '*.php'`
