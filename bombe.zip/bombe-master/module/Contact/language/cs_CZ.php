<?php
/*
 * Translations for other parts of system such as Form etc.
 */
return array(
    "From:" => "Odesílatel (email):",
    "Subject:" => "Předmět:",
    "Your message:" => "Text zprávy:",
    "Please verify you are human." => "Ověření, že jste člověk:",
    "Send" => "Odeslat"
);