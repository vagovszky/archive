<?php

namespace DataStorage;

return array(
    'controllers' => array(
        'invokables' => array(
            'DataStorage\Controller\Administration' => 'DataStorage\Controller\AdministrationController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'zfcadmin' => array(
                'child_routes' => array(
                    'datastorage' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/datastorage',
                            'defaults' => array(
                                '__NAMESPACE__' => 'DataStorage\Controller',
                                'controller' => 'Administration',
                                'action' => 'index',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'upload' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/upload',
                                    'defaults' => array(
                                        'action' => 'upload',
                                    ),
                                ),
                            ),
                            'success' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/success',
                                    'defaults' => array(
                                        'action' => 'success',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'DataStorage' => __DIR__ . '/../view',
        ),
    ),
    'translator' => array(
        'translation_file_patterns' => array(
            array(
                'type' => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern' => '%s.mo',
                'text_domain' => __NAMESPACE__,
            ),
            array(
                'type'     => 'phparray',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.php',
                'text_domain' => __NAMESPACE__,
            )
        ),
    ),
    'doctrine' => array(
        'driver' => array(
            __NAMESPACE__ . '_driver' => array(
                'class' => 'Doctrine\ORM\Mapping\Driver\AnnotationDriver',
                'cache' => 'array',
                'paths' => array(__DIR__ . '/../src/' . __NAMESPACE__ . '/Entity')
            ),
            'orm_default' => array(
                'drivers' => array(
                    __NAMESPACE__ . '\Entity' => __NAMESPACE__ . '_driver'
                ),
            ),
        ),
    )
);
