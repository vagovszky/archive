<?php
/*
 * Translations for other parts of system such as Form etc.
 */
return array(
    "Text Entry" => "Text:",
    "Multi-File Input" => "Soubor(y):",
    "Submit" => "Odeslat"
);