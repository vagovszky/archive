<?php
namespace DataStorage\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use DataStorage\Entity\File;
use Doctrine\ORM\EntityManager;
use Zend\View\Model\ViewModel;

class AdministrationController extends AbstractActionController
{
    protected $sessionContainer;

    protected $em;

    public function __construct()
    {
        $this->sessionContainer = new \Zend\Session\Container('datastorage_administration');
    }
    
    public function setEntityManager(EntityManager $em) {
        $this->em = $em;
    }

    public function getEntityManager() {
        if (null === $this->em) {
            $this->em = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        }
        return $this->em;
    }
    
    public function indexAction()
    {
        $id = $this->getEvent()->getRouteMatch()->getParam('id');
        $directory = $this->getEntityManager()->getRepository('DataStorage\Entity\Directory');
        //$root = $directory->findOneBy(array('name'=>'/'));
        $root = $directory->findOneByName("/");
        $vm = new ViewModel();
        $vm->setVariable('directory', $directory);
        $vm->setVariable('root', $root);
        $vm->setVariable('id', $id);
        return $vm;
    }
    
    public function successAction()
    {
        return array(
            'uploaded' => $this->sessionContainer->uploaded,
        );
    }

    protected function redirectToSuccessPage($uploaded = null)
    {
        $this->sessionContainer->uploaded = $uploaded;
        $response = $this->redirect()->toRoute('zfcadmin/datastorage/success');
        $response->setStatusCode(303);
        return $response;
    }
    
    public function uploadAction(){
        $form = new \DataStorage\Form\MultiHtml5Upload('file-form');

        if ($this->getRequest()->isPost()) {
            // Postback
            $data = array_merge_recursive(
                $this->getRequest()->getPost()->toArray(),
                $this->getRequest()->getFiles()->toArray()
            );

            $form->setData($data);
            if ($form->isValid()) {
                $form_data = $form->getData();
                if($this->zfcUserAuthentication()->hasIdentity()){
                    $user = $this->zfcUserAuthentication()->getIdentity();
                }else{
                    $user = NULL;
                }
                $count_uploaded_files = 0;
                $count_errors = 0;
                foreach($form_data['file'] as $file){
                    $hash = md5_file($file['tmp_name']);
                    $fileEntity = new File($user);
                    $fileEntity->setActive(true);
                    $fileEntity->setName($file['name']);
                    $fileEntity->setSize($file['size']);
                    $fileEntity->setHash($hash);
                    $fileEntity->setType($file['type']);
                    $fileEntity->setUploaded(new \DateTime());
                    try{
                        $success = copy(ROOT_DIR."/".$file['tmp_name'], ROOT_DIR."/data/storage/".$hash);
                    }catch(\Exception $e){
                        $success = false;
                    }
                    if($success){
                        $this->getEntityManager()->persist($fileEntity);
                        $this->getEntityManager()->flush();
                        unlink(ROOT_DIR."/".$file['tmp_name']);
                        $count_uploaded_files++;
                    }else{
                        $count_errors ++;
                    }
                }
                // save here
                return $this->redirectToSuccessPage(
                        array(
                            'count_uploaded_files' => $count_uploaded_files,
                            'count_errors' => $count_errors
                            )
                );
            }
        }

        $view = new \Zend\View\Model\ViewModel(array(
           'form'   => $form,
        ));
        return $view;
    }
}
