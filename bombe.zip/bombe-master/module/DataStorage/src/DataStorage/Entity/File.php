<?php

namespace DataStorage\Entity;

use Doctrine\ORM\Mapping as ORM;
use Application\Entity\User;


/**
 * File entitiy
 *
 * @ORM\Entity
 * @ORM\Table(name="files", indexes={@ORM\Index(name="hash_idx", columns={"hash"})})
 */
class File {

    /**
     * @ORM\Id
     * @ORM\Column(type="integer");
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=250, nullable=true)
     */
    protected $name;

    /**
     * @ORM\Column(type="string", length=100, nullable=true)
     */
    protected $type;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $size;

    /**
     * @ORM\Column(type="string", length=40, nullable=true, unique=true)
     */
    protected $hash;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    protected $uploaded;

    /**
     * @ORM\Column(type="boolean")
     */
    protected $active;
    
    /**
     * @ORM\ManyToOne(targetEntity="Application\Entity\User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id", nullable=true, onDelete="SET NULL")
     **/
    private $user;
    
    
    public function __construct($user = null){
        $this->user = $user;
    }
    
    public function getId(){
        return $this->id;
    }
    
    public function getName(){
        return $this->name;
    }
    
    public function getType(){
        return $this->type;
    }
    
    public function getSize(){
        return $this->size;
    }
    
    public function getHash(){
        return $this->hash;
    }
    
    public function getUploaded(){
        return $this->uploaded;
    }
    
    public function isActive(){
        return $this->active;
    }
    
    public function getUser(){
        return $this->user;
    }
    
    public function setName($name){
        $this->name = (isset($name)) ? $name : null;
        return $this;
    }
    
    public function setType($type){
        $this->type = (isset($type)) ? $type : null;
        return $this;
    }
    
    public function setSize($size){
        $this->size = (isset($size)) ? $size : null;
        return $this;
    }
    
    public function setUploaded($uploaded){
        if(isset($uploaded)){
            if(is_string($uploaded)){
                $this->uploaded = new \DateTime($uploaded);
            }elseif($uploaded instanceof \DateTime){
                $this->uploaded = $uploaded;
            }else{
                $this->uploaded = null; 
            }
        }else{
            $this->uploaded = null; 
        }
        return $this;
    }
    
    public function setHash($hash){
        $this->hash = (isset($hash)) ? $hash : null;
        return $this;
    }
    
    public function setActive($active){
        $this->active = (isset($active)) ? (bool) $active : null;
        return $this;
    }
    
    public function setUser($user){
        $this->user = ($user instanceof User) ? $user : null;
        return $this;
    }
}    

?>
