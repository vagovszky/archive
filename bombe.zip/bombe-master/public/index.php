<?php
date_default_timezone_set('Europe/Prague');

define('PUBLIC_DIR', __DIR__);
define('ROOT_DIR', __DIR__.'/../');

define('VERSION','1.0.0 beta1');

error_reporting(E_ALL & ~E_STRICT);
ini_set('display_errors', '1');

define('REQUEST_MICROTIME', microtime(true));

chdir(dirname(__DIR__));

require 'init_autoloader.php';

Zend\Mvc\Application::init(require 'config/application.config.php')->run();
