<?php
date_default_timezone_set('Europe/Prague');

define('ROOT_DIR', __DIR__.'/../');
define('PUBLIC_DIR', ROOT_DIR."/public/");

chdir(dirname(__DIR__));

include ROOT_DIR.'/init_autoloader.php';