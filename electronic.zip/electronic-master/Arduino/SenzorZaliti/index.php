<!DOCTYPE html>
<!--
http://cssdeck.com/labs/percentage-bar
-->
<html>
    <head>
        <title>Senzor zalití</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="jquery.js" type="text/javascript"></script>
        <script src="javascript.js" type="text/javascript"></script>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php
        $read = exec('./data');
        ?>
        <div id="container">
            <h2>Stav zalití kvítka</h2>
            <div id="bar-1" class="bar-main-container azure">
                <div class="wrap">
                    <div class="bar-percentage" data-percentage="<?php echo $read; ?>"></div>
                    <div class="bar-container">
                        <div class="bar"></div>
                    </div>
                </div>
            </div>
            <button name="zalij" id="zalij">Zalij</button>
        </div>
    </body>
</html>






