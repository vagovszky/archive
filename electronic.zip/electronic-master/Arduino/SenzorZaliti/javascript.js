$().ready(function() {
    
    var timer = setTimeout(function(){
        window.location.reload(1);
    }, 8000);
    
    $('.bar-percentage[data-percentage]').each(function() {
        var progress = $(this);
        var percentage = Math.ceil($(this).attr('data-percentage'));
        
        var pct = '';
        pct = Math.floor(percentage) + '%';
        progress.text(pct) && progress.siblings().children().css('width', pct);
    });
    
    $("#zalij").click(function(){
       clearTimeout(timer);
       $.get("zalij.php");
       timer = setTimeout(function(){
        window.location.reload(1);
       }, 8000);
    });
});