<?php
// stty -F /dev/ttyACM0 cs8 9600 ignbrk -brkint -imaxbel -opost -onlcr -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke noflsh -ixon -crtscts
include(__DIR__ . "/libs/PhpSerial.php");
try {
    $serial = new PhpSerial;
    $serial->deviceSet("/dev/ttyACM0");
    $serial->confBaudRate(9600);
    $serial->confParity("none");
    $serial->confCharacterLength(8);
    $serial->confStopBits(1);
    $serial->confFlowControl("none");
    $serial->deviceOpen("w+");
    sleep(2);
    $serial->sendMessage('z');
    $serial->deviceClose();
} catch (\Exception $e) {
    
}
