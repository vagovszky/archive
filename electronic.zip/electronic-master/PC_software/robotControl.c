#include <stdio.h>   /* Standard input/output definitions */
#include <stdlib.h>
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <sys/ioctl.h>
#include <ncurses.h>

// gcc -o test test.c -lncurses

int open_port(char* port)
{
  int fd;
  fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
    perror("open_port: Unable to open serial port\n");
  }
  else
    fcntl(fd, F_SETFL, 0);
  return (fd);
}

void close_port(fd){
    close(fd);
}

int configure_port(int fd){
  struct termios options;
  tcgetattr(fd, &options);
  cfsetispeed(&options, B9600);
  cfsetospeed(&options, B9600);

  options.c_cflag |= (CLOCAL | CREAD);
  options.c_cflag &= ~PARENB;
  options.c_cflag &= ~CSTOPB;
  options.c_cflag &= ~CSIZE;
  options.c_cflag |= CS8;
  
  options.c_cflag &=  ~CRTSCTS;
  options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
  options.c_iflag |= (INPCK | ISTRIP);

  options.c_iflag &= ~(IXON | IXOFF | IXANY);

  options.c_oflag &= ~OPOST;
  options.c_cc[VMIN] = 1;                  // read doesn't block
  options.c_cc[VTIME] = 5;

  tcflush(fd, TCIFLUSH );
  
  tcsetattr(fd, TCSANOW, &options);
}


int main( int num_args, char* args[] ) 
{ 

    char c;
    int fd,choice;
    char* port;

    initscr();
    printw("Ovlada se sipkama, stopka je mezernik, q - konec\n");
    refresh();
    
    
    port = "/dev/rfcomm0";
    printf("Opening port %s\n", port); 
    fd = open_port(port);
    if (fd < 0){
        printf("Couldn't open %s\n",port);
        return(1);
    }
    configure_port(fd);
    
    while(1)
	{	c = getch();
		choice = 1;
		switch(c)
		{	case '2':
				write(fd,"2",1);
				break;
			case '8':
				write(fd,"8",1);
				break;
			case '4':
				write(fd,"4",1);
				break;
			case '6':
				write(fd,"6",1);
				break;
			case 'q':
				choice = 0;
				break;
			default:
				write(fd,"5",1);
				break;
		}
		refresh();
		if(choice == 0)	break;
	}	
    
    close_port(fd);
    endwin();
    return 0;
} 


