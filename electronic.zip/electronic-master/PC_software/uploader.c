#include <stdio.h>   /* Standard input/output definitions */
#include <stdlib.h>
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <sys/ioctl.h>
// #include <ncurses.h>

// gcc -o test test.c -lncurses

int open_port(char* port)
{
  int fd;
  fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
    perror("open_port: Unable to open serial port\n");
  }
  else
    fcntl(fd, F_SETFL, 0);
  return (fd);
}

void close_port(fd){
    close(fd);
}

int configure_port(int fd){
  struct termios options;
  tcgetattr(fd, &options);
  cfsetispeed(&options, B57600);
  cfsetospeed(&options, B57600);

  options.c_cflag |= (CLOCAL | CREAD);
  options.c_cflag &= ~PARENB;
  options.c_cflag &= ~CSTOPB;
  options.c_cflag &= ~CSIZE;
  options.c_cflag |= CS8;
  
  options.c_cflag &=  ~CRTSCTS;
  options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
  options.c_iflag |= (INPCK | ISTRIP);

  options.c_iflag &= ~(IXON | IXOFF | IXANY);

  options.c_oflag &= ~OPOST;
  options.c_cc[VMIN] = 1;                  // read doesn't block
  options.c_cc[VTIME] = 5;

  tcflush(fd, TCIFLUSH );
  
  tcsetattr(fd, TCSANOW, &options);
}

void setRTS(int fd){
  int status;
  ioctl(fd, TIOCMGET, &status);
  status |= TIOCM_RTS;
  ioctl(fd, TIOCMSET, &status);
  usleep(10000);
}

void clrRTS(int fd){
  int status;
  ioctl(fd, TIOCMGET, &status);
  status &= ~TIOCM_RTS;
  ioctl(fd, TIOCMSET, &status);
  usleep(10000);
}

void setDTR(int fd){
  int status;
  ioctl(fd, TIOCMGET, &status);
  status |= TIOCM_DTR;
  ioctl(fd, TIOCMSET, &status);
  usleep(10000);
}

void clrDTR(int fd){
  int status;
  ioctl(fd, TIOCMGET, &status);
  status &= ~TIOCM_DTR;
  ioctl(fd, TIOCMSET, &status);
  usleep(10000);
}

int main( int num_args, char* args[] ) 
{ 
  /*
    char c;
    initscr();
    printw("Hello World !!!");
    refresh();
    c = getch();
    printw("Zmackls %c\n", c);
    getch();
    endwin();
    return 0;
  */
    int fd;
    char* port;
    FILE *fp;
    size_t size; 
    int i;
    unsigned char *buffer;
    
    if(num_args < 3){
        printf("A too litle count of arguments\n"); 
        return(1);
    }

    port = args[1];
    printf("Opening port %s\n", port); 
    fd = open_port(port);
    if (fd < 0){
        printf("Couldn't open %s\n",port);
        return(1);
    }
    configure_port(fd);
    clrRTS(fd);
    clrDTR(fd);
    usleep(10000);
    // ------------------------------------
    setRTS(fd);
    usleep(10000);
    // ------------------------------------
    
    fp = fopen(args[2], "rb");
    if (fp == NULL){
       printf("File doesn't exist\n");
    }else {
      // ====================================
      fseek(fp, 0, SEEK_END); 
      size = ftell(fp);         /*calc the size needed*/
      fseek(fp, 0, SEEK_SET); 
      buffer = (unsigned char *) malloc(size);
    
      if (fread(buffer,sizeof(buffer[0]), size, fp) != size){
          printf("Error: There was an Error reading the file");
      }else{
	printf("File size %zu bytes\n",size);
	for(i=0; i<size;i++){ 
            write(fd,&buffer[i],1);
        }
      }
      // ===================================
    }
     
    fclose(fp);
    free(buffer);
    usleep(100000);
    // ------------------------------------
    clrRTS(fd);
    setDTR(fd);
    usleep(100000);
    setRTS(fd);
    // ------------------------------------
    printf("Program running...\n");
    getchar();
    printf("Program terminated\n");
    clrRTS(fd);
    clrDTR(fd);
    usleep(100000);
    close_port(fd);
    return 0;
} 


