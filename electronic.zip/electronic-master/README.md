electronic
==========

PC_software/uploader.c - upload SDCC compiled .bin files to HW emulator through RS 232
