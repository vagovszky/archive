<?php
return array(
    'asset_bundle' => array(
	'production' => false, // Switch to true if production
        'cacheUrl' => '@zfBaseUrl/cache/',
    ),
);
?>
