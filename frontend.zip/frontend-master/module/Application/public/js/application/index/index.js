/**
 * Index controller index action javascript
 * https://github.com/colintoh/skylo
 */

function Tip(row){
    var self = this;

    self.id = row.id;
    self.sport = row.sport;
    self.region = row.region;
    self.ligue = row.ligue;
    self.match = row.match;
    self.start = row.start;
    self.result = row.result;
    self.tip = row.tip;
    self.course = row.course;
    self.bet = row.bet;
    self.enrolled = row.enrolled;
    self.rslt = row.rslt;
    
    self.getClass = function(){
        if(self.rslt == 'vyhra'){
            return 'success';
        }else if(self.rslt == 'prohra'){
            return 'danger';
        }else{
            return '';
        }
    }
}

function AppIndexViewModel() {
    var self = this;
    self.tips = ko.observableArray([]);

    $(document).skylo('start');
    $(document).skylo('show',function(){
        $(document).skylo('inch',50);
    });
    $.getJSON("tips", function(allData) {
        $(document).skylo('show',function(){
            $(document).skylo('set',70);
        });
        var mappedTips = $.map(allData, function(item) {
            return new Tip(item)
        });
        self.tips(mappedTips);
        $(document).skylo('end');
    });  
}

// Activates knockout.js
ko.applyBindings(new AppIndexViewModel());

