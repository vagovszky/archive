<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2013 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Doctrine\ORM\EntityManager;
use Zend\Json\Json;

class IndexController extends AbstractActionController
{
    
    protected $em;

    public function setEntityManager(EntityManager $em) {
        $this->em = $em;
    }

    public function getEntityManager() {
        if (null === $this->em) {
            $this->em = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        }
        return $this->em;
    }
    
    public function tipsAction(){
        $query = $this->getEntityManager()->createQuery('SELECT t FROM BetDatabase\Entity\Tips t ORDER BY t.datetime_created DESC');
        $result = $query->setMaxResults(30)->getResult();
        $tips = array();
        foreach ($result as $tip) {
            $odd = $tip->getOdd();
            $match = $odd->getMatch();
            $ligue = $match->getBettype()->getLigue();
            $tips[] = array(
                'id' => $tip->getId(),
                'sport' => $ligue->getSport(),
                'region' => $ligue->getRegion(),
                'ligue' => $ligue->getName(),
                'match' => $match->getName(),
                'start' => $match->getDatetime()->format('d.m.Y H:i'),
                'result' => $match->getResult(),
                'tip' => $odd->getName(),
                'course' => $odd->getValue(),
                'bet' => $tip->getBet(),
                'enrolled' => $tip->getDatetimeCreated()->format('d.m.Y H:i'),
                'rslt' => $odd->getResult()
            );
        }
        return new JsonModel($tips);
    }
}
