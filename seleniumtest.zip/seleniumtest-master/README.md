Selenium test script
=======================

Author: Martin Vágovszký

- php composer.phar install
- cd build && ./create_phar.sh
- use seleniumtest.phar and config.php to run test

Note.: running selenium server needed