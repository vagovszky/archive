<?php
$wd_host = 'http://localhost:4444/wd/hub';
$url = 'http://seznam.cz';
$screenshotsDir = "/tmp/screenshots";
$browser = "firefox";
$window_width = 800;
$window_height = 600;
?>
