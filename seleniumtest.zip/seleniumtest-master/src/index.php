#!/usr/bin/env php
<?php
/**
 * Adaxet test script by Martin Vágovszký
 */
//require(__DIR__."/WebDriver/__init__.php");
require(__DIR__."/../vendor/autoload.php");

/**
 * Čeká na dokončení ajaxového požadavku
 * @param WebDriver $driver
 */
function waitForAjax($driver) {
    do {
        sleep(2);
    } while($driver->executeScript('return jQuery.active'));
}

if(file_exists("config.php")){
    include("config.php");
}else{
    $wd_host = 'http://localhost:4444/wd/hub';
    $url = 'http://www.seznam.cz';
    $screenshotsDir = "/tmp/screenshots";
    $browser = "firefox";
    $window_width = 800;
    $window_height = 600;
}

if(!file_exists($screenshotsDir)){
    mkdir($screenshotsDir);
}

// Delete screenshots
foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($screenshotsDir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $path) {
    $path->isFile() ? unlink($path->getPathname()) : rmdir($path->getPathname());
}

// create webdriver session
try{
    $capabilities = array(WebDriverCapabilityType::BROWSER_NAME => $browser);
    $driver = new WebDriver($wd_host, $capabilities);
}catch(\Exception $e){
    die('Can not create WebDriver session\n');
}

try{
    $dimensions = new WebDriverDimension($window_width, $window_height);
    $driver->manage()->window()->setSize($dimensions);
}catch(\Exception $e){
    echo "Can not resize window\n";
}

$driver->get($url);
$driver->takeScreenshot($screenshotsDir."/screenshot.png"); // create screenshot
$driver->close();
?>
