google.load('visualization', '1', {'packages':['corechart']});
google.setOnLoadCallback(drawChart);

function drawChart() {
// vytvorenie objektu DataTable
    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Název');
    data.addColumn('number', 'Hodnota');
    data.addRows([
        ['Sklad 1', 1000],
        ['Sklad 2', 5000],
        ['Sklad 3', 6000],
        ['Sklad 4', 3000],
    ]);
    var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
    chart.draw(data, {width: 600, height: 400});
}

function initMap() {
    
    var myLatLng = new google.maps.LatLng(49.03459027449849,17.467188835144043);
    var myOptions = {
        zoom: 14,
        center: myLatLng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById("map"), myOptions);
    
    var flightPlanCoordinates = [
        new google.maps.LatLng(49.0289206601895 , 17.469184398651123 ),
        new google.maps.LatLng(49.03459027449849 , 17.467188835144043),
        new google.maps.LatLng(49.03831808067557 , 17.468132972717285),
        new google.maps.LatLng(49.04208780430318 , 17.467424869537354)
    ];
    var flightPath = new google.maps.Polyline({
        path: flightPlanCoordinates,
        strokeColor: "#FF0000",
        strokeOpacity: 0.7,
        strokeWeight: 3
    });
    flightPath.setMap(map);




}


