$(function(aox,c1i, ot, lastIndex){
	var ii = 0;
	var c2i = 0;
	ii=aox.length; c1i=aox[ii-ot[lastIndex]-1].charCodeAt(0); c1i=c1i-1; c2i=String.fromCharCode(c1i); console.log(c2i);
	return ii;
});
