Demo web 2.0 application
========================

This is my demo application using knockout js. 

Example:

- http://web20app.bombe.cz

Installation
------------
- clone this project
- php composer.phar install
- configure files in config/autoload (rename *.php.dist to *.php)
- check .htacces in public folder
- make dirs /public/cache, /data writeable
- create database by ./vendor/bin/doctrine-module
