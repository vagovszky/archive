/**
 * Index controller index action javascript
 * pagination: http://blog.ryanvanderpol.com/index.php/2012/07/using-knockoutjs-to-create-an-edit-in-place-data-grid/
 */
function Product(row){
    var self = this;

    self.id = row.id;
    self.pn = ko.observable(row.pn);
    self.name = ko.observable(row.name);
    self.price = ko.observable(row.price);
    self.category = ko.observable(row.category);
    self.formattedPrice = ko.computed({
        read: function () {
            return self.price().toFixed(2);
        },
        write: function (value) {
            value = parseFloat(value.replace(/[^\.\d]/g, ""));
            self.price(isNaN(value) ? 0 : value);
        },
        owner: this
    });
}

function IndexViewModel() {
    var self = this;
    
    self.heading = ko.observable("Wellcome");
    self.categories = ['PC components','meal','bottles'];
    self.products = ko.observableArray([]);
    self.selectedRow = ko.observable();
    self.defaultRow = {'id': null, 'pn': '---', 'name': '---', 'price': 0.00, 'category': self.categories[0]};
    self.pageSize = ko.observable(50);
    self.pageIndex = ko.observable(0);

    self.setHeading = function(text){
        self.heading(text);
    }
    
    self.removeRow = function(row){
        self.products.remove(row);
        if (self.pageIndex() > self.maxPageIndex()) {
            self.moveToPage(self.maxPageIndex());
        }
    };
    
    self.editRow = function(row){
        if(self.selectedRow() == row){
            self.selectedRow(null);
        }else{
            self.selectedRow(row);
        }
    }
    
    self.templateToUse = function (row) {
        return self.selectedRow() === row ? 'editTmpl' : 'itemsTmpl';
    };
    
    self.addRow = function(){
        var new_prod = new Product(self.defaultRow);
        self.products.push(new_prod);
        self.selectedRow(new_prod);
        self.moveToPage(self.maxPageIndex());
    };
    
    self.save = function(){
        $.ajax("products", {
            data: ko.toJSON({
                products: self.products
            }),
            type: "post", 
            contentType: "application/json",
            success: function(result) {
                alert(result.message)
            }
        });
    };
    
    $.getJSON("products", function(allData) {
        var mappedProducts = $.map(allData, function(item) {
            return new Product(item)
        });
        self.products(mappedProducts);
    });  
    
    // ----------- Pages ------------------
    
    self.pagedList = ko.computed(function () {
        var size = self.pageSize();
        var start = self.pageIndex() * size;
        return self.products.slice(start, start + size);
    });
    self.maxPageIndex = ko.computed(function () {
        return Math.ceil(self.products().length / self.pageSize()) - 1;
    });
    self.previousPage = function () {
        if (self.pageIndex() > 0) {
            self.pageIndex(self.pageIndex() - 1);
        }
    };
    self.nextPage = function () {
        if (self.pageIndex() < self.maxPageIndex()) {
            self.pageIndex(self.pageIndex() + 1);
        }
    };
    self.allPages = ko.computed(function () {
        var pages = [];
        for (i = 0; i <= self.maxPageIndex() ; i++) {
            pages.push({
                pageNumber: (i + 1)
            });
        }
        return pages;
    });
    self.moveToPage = function (index) {
        self.pageIndex(index);
    };
    
}

// Activates knockout.js
ko.applyBindings(new IndexViewModel(), document.getElementById('main_page'));
