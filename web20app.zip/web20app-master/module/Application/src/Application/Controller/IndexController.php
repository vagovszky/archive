<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Doctrine\ORM\EntityManager;
use Zend\Json\Json;
use Application\Entity\Product;

class IndexController extends AbstractActionController {

    protected $em;

    public function setEntityManager(EntityManager $em) {
        $this->em = $em;
    }

    public function getEntityManager() {
        if (null === $this->em) {
            $this->em = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        }
        return $this->em;
    }
    
    public function productsAction() {
        if ($this->getRequest()->isPost()) {
            //save data
            $post = Json::decode($this->getRequest()->getContent());
            $this->saveData($post->products);
            return new JsonModel(array('message' => "Products were updated"));
        } else {
            //load data
            $data = $this->getEntityManager()->getRepository('Application\Entity\Product')->findAll();
            $products = array();
            foreach ($data as $product) {
                $products[] = $product->getObject();
            }
            $result = new JsonModel($products);
            return $result;
        }
    }
    
    private function saveData($products){
        $oldCollection = $this->getEntityManager()->getRepository('Application\Entity\Product')->findAll();
        $newUpdateIds = array();
        $newProductsUpdate = array();
        $newProductsInsert = array();
        foreach($products as $product){
            if(empty($product->id)){
                $newProductsInsert[] = $product;
            }else{
                $newUpdateIds[] = $product->id;
                $newProductsUpdate[$product->id] = $product;
            }
        }
        // Update or remove existing data
        foreach($oldCollection as $oldProduct){
            $oldProductId = $oldProduct->getId();
            if(in_array($oldProductId, $newUpdateIds)){
                // update
                $newProductUpdate = $newProductsUpdate[$oldProductId];
                $oldProduct->loadFromObject($newProductUpdate);
                $this->getEntityManager()->persist($oldProduct);
            }else{
                // remove
                $this->getEntityManager()->remove($oldProduct);
            }
        }
        // Insert new Items
        foreach($newProductsInsert as $newProduct){
            $newProductInsert = new Product();
            $newProductInsert->loadFromObject($newProduct);
            $this->getEntityManager()->persist($newProductInsert);
        }
        $this->getEntityManager()->flush();
    }

}
