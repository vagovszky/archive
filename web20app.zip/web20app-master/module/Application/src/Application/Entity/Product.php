<?php

namespace Application\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * File entitiy
 *
 * @ORM\Entity
 * @ORM\Table(name="products", indexes={@ORM\Index(name="products_idx", columns={"pn"})})
 */
class Product {

    /**
     * @ORM\Id
     * @ORM\Column(type="integer", nullable=false)
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id = null;

    /**
     * @ORM\Column(type="string", length=12, nullable=true)
     */
    protected $pn = '';

    /**
     * @ORM\Column(type="string", length=250, nullable=true)
     */
    protected $name = '';

    /**
     * @ORM\Column(type="decimal", scale=2, nullable=true)
     */
    protected $price = 0;

    /**
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    protected $category = '';

    public function __construct($user = null) {
        $this->user = $user;
    }

    public function getId() {
        return $this->id;
    }

    public function getName() {
        return $this->name;
    }

    public function getPn() {
        return $this->pn;
    }

    public function getPrice() {
        return $this->price;
    }

    public function getCategory() {
        return $this->category;
    }

    public function setId($id){
        $this->id = (isset($id)) ? $id : null;
        return $this;
    }
    
    public function setName($name) {
        $this->name = (isset($name)) ? $name : null;
        return $this;
    }

    public function setPn($pn) {
        $this->pn = (isset($pn)) ? $pn : null;
        return $this;
    }

    public function setPrice($price) {
        $this->price = (isset($price)) ? $price : 0;
        return $this;
    }

    public function setCategory($category) {
        $this->category = (isset($category)) ? $category : null;
        return $this;
    }

    public function getObject() {
        $p = new \stdClass;
        $p->id = $this->getId();
        $p->name = $this->getName();
        $p->pn = $this->getPn();
        $p->price = floatval($this->getPrice());
        $p->category = $this->getCategory();
        return $p;
    }
    
    public function loadFromObject(\stdClass $object){
        if(isset($object->id)) $this->setId($object->id);
        if(isset($object->name)) $this->setName($object->name);
        if(isset($object->price)) $this->setPrice($object->price);
        if(isset($object->pn)) $this->setPn($object->pn);
        if(isset($object->category)) $this->setCategory($object->category);
        return $this;
    }

}

?>
