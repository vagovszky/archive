$(document).ready(function(){
   SyntaxHighlighter.all();
});


