<?php

namespace Article\Listener;

use Zend\EventManager\ListenerAggregateInterface;
use Zend\EventManager\EventInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\EventManager\SharedListenerAggregateInterface;
use Zend\EventManager\SharedEventManagerInterface;

class LogListener implements SharedListenerAggregateInterface{
    
    protected $logger;
    protected $listeners = array();
    protected $serviceLocator;
    
    public function __construct(ServiceLocatorInterface $sm)
    {
        $this->logger = $sm->get('logger');
        $this->serviceLocator = $sm;
    }

    public function attachShared(SharedEventManagerInterface $events)
    {
        $this->listeners[] = $events->attach(
                'Article\Controller\AdministrationController',array(
                    'editArticle.post',
                    'addArticle.post',
                    'deleteArticle.post',
                    'editArticlesGroup.post',
                    'addArticlesGroup.post',
                    'deleteArticlesGroup.post'
                ), 
                array($this, 'logArticle'), 100);
    }

    public function detachShared(SharedEventManagerInterface $events)
    {
        foreach ($this->listeners as $index => $listener) {
            if ($events->detach($listener)) {
                unset($this->listeners[$index]);
            }
        }
    }
    
    public function logArticle(EventInterface $e){
        $event_name = $e->getName();
        $user = $this->serviceLocator->get('zfcuser_auth_service')->getIdentity();
        $article = $e->getParam('article');
        $articlesGroup = $e->getParam('articlesGroup');
        switch ($event_name){
            case "editArticle.post":
                $this->logger->log('Edit article '.$article->getTitle().' by user '.$user->getDisplayName());
            break;
            case "addArticle.post":
                $this->logger->log('Add article '.$article->getTitle().' by user '.$user->getDisplayName());
            break;
            case "deleteArticle.post":
                $this->logger->log('Delete article '.$article->getTitle().' by user '.$user->getDisplayName());
            break;
            case "editArticlesGroup.post":
                $this->logger->log('Edit articles group '.$articlesGroup->getName().' by user '.$user->getDisplayName());
            break;
            case "addArticlesGroup.post":
                $this->logger->log('Add articles group '.$articlesGroup->getName().' by user '.$user->getDisplayName());
            break;
            case "deleteArticlesGroup.post":
                $this->logger->log('Delete articles group '.$articlesGroup->getName().' by user '.$user->getDisplayName());
            break;
        }
    }
}

?>
