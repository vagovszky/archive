$().ready(function(){
   $('#category_route_type').change(function(){
       $('input[name="reload"]').click();
   });
});


