$(document).ready(function() {
    $.application.init();
});