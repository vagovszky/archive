$(document).ready(function() {
    $.application.init();
    $( ".main-menu" ).menu();
});